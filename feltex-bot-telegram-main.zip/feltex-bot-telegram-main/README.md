## Criando o seu bot

Link do vídeo: https://www.youtube.com/watch?v=eawDe1-jMDM

Adicione a conta ```botFather``` no seu Telegram. Este bot exibirá os comandos para voce criar o bot. 

    @botfather

Crie o bot com o nome desejado

BotName   ```Canal Feltex```
UserName  ```feltexUserName_bot```


# Resposta do Bot

O bot responde aos comandos
    
    /help
    olá
    data
    hora
    quem é você


