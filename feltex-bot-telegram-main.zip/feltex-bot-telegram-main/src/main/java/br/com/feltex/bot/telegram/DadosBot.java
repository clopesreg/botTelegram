package br.com.feltex.bot.telegram;

public class DadosBot {
    public static final String BOT_TOKEN = "";
    public static final String BOT_USER_NAME = "";
}
